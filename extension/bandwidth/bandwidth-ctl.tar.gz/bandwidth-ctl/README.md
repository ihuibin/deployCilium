# bandwidth-ctl Helm Chart

A Helm chart for deploying bandwidth-ctl with network configuration for Spidernet ecosystem.

## Prerequisites

- Kubernetes 1.16+
- Helm 3.0+
- Spiderpool installed for IP management
- Multus CNI installed for multiple network interfaces

## Installing the Chart

To install the chart with the release name `bandwidth-ctl`:

```bash
helm install bandwidth-ctl ./bandwidth-ctl